corr_lab_auto <- c(
  "concordance" = "(Concordance)",
  "pearson" = "(Pearson)",
  "spearman" = "(Spearman)",
  "kendall" = "(Kendall)"
)